export const dinosaurs = [
  {
    id: 1,
    name: 'ティラノサウルス',
    image: 'https://images.unsplash.com/photo-1525877442103-5ddb2089b2bb?auto=format&fit=crop&q=80',
    choices: ['ティラノサウルス', 'ヴェロキラプトル', 'スピノサウルス']
  },
  {
    id: 2,
    name: 'ステゴサウルス',
    image: 'https://images.unsplash.com/photo-1534067783941-51c9c23ecefd?auto=format&fit=crop&q=80',
    choices: ['ステゴサウルス', 'アンキロサウルス', 'トリケラトプス']
  },
  {
    id: 3,
    name: 'ヴェロキラプトル',
    image: 'https://images.unsplash.com/photo-1519880772-8b2edf2f6484?auto=format&fit=crop&q=80',
    choices: ['ヴェロキラプトル', 'デイノニクス', 'ユタラプトル']
  }
];